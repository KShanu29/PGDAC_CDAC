#include<iostream>
#include<bits/stdc++.h>
using namespace std;

class Emp
{
	public:
	int empid,sal,yj;
	char name[33];
	
	int tax(int n)
	{
		int tax;
		tax=n*0.1;
		return tax; 
	}
};
	void SearchbyId(Emp ar[],int c)
	{
		int id;
		printf("enter employee's Id: ");
		scanf("%d",&id);
		for(int i=1;i<=c;i++)
		{
			if(id==ar[i].empid)
			{
				printf("\nemployee's id: %d",ar[i].empid);
				printf("\nemployee's name: %s",ar[i].name);
				printf("\nemployee's salary: %d",ar[i].sal);
				printf("\nemployee's year of joining: %d",ar[i].yj);
				printf("\n__________________________________________");
			}
		}
	}
	void SearchbyYear(Emp arr[],int t)
	{
		int yr;
		printf("enter employee's year of joining: ");
		scanf("%d",&yr);
		for(int i=1;i<=t;i++)
		{
			if(yr==arr[i].yj)
			{
				printf("\nemployee's id: %d",arr[i].empid);
				printf("\nemployee's name: %s",arr[i].name);
				printf("\nemployee's salary: %d",arr[i].sal);
				printf("\nemployee's year of joining: %d",arr[i].yj);
				printf("\n__________________________________________");
			}
		}
}
int main()
{
	int tx,totalsal=0,minsal,maxsal=0,avgsal,count=0;
	char c;
	Emp e[40];
	p:
		++count;
		cout<<"enter employee's ID: ";
		cin>>e[count].empid;
		
		cout<<"enter employee's Name: ";
		cin>>e[count].name;
		
		cout<<"enter employee's Salary: ";
		cin>>e[count].sal;
		
		cout<<"enter employee's year of joining: ";
		cin>>e[count].yj;
		
		tx=e[count].tax(e[count].sal);
		totalsal+=e[count].sal-tx;
		
		cout<<"Do you want to continue[y/n]: ";
		cin>>c;
		if(c=='y'|c=='Y')
			goto p;
		else
		{
			avgsal=totalsal/count;
			printf("\nTotal employee's salary: %d",totalsal);
			printf("\nAvg. employee's salary: %d",avgsal);
			for(int i=1;i<=count;i++)
				if(e[count].sal>maxsal)
					maxsal=e[count].sal;
				else
					minsal=e[count].sal;
			printf("\nMax employee's salary: %d",maxsal);
			printf("\nMin employee's salary: %d",minsal);
			printf("\n___________________________________________");
			printf("\n1. for search by eid");
			printf("\n2. for search by joininig year");
			printf("\n3. for exit");
			int m,id,year;
			printf("\nenter your choice: ");
			scanf("%d",&m);
			switch(m)
			{
				case 1:
					SearchbyId(e,count);
					break;  
				case 2:
					SearchbyYear(e,count);
					break;
				case 3:
					exit(1);
					break;
				default:
					printf("\nInvalid option");
			}  
		}
}
