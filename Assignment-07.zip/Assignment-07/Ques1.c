#include<stdio.h>
#include<string.h>

int main()
{
	char str1[]="KUMAR ";
	char str2[]="SHANU";
	char ss[20];
	strcpy(ss,str1);
	int len=strlen(str1);
	printf("--------------------------------------------------\n");
	printf("The length of string is %d",len);
	printf("\n--------------------------------------------------");
	printf("\nThe concatenation of %s and %s is: %s",ss,str2,strcat(str1,str2));
	printf("\n--------------------------------------------------");
	int q=strcmp(ss,str2);
	if(q==0)
	printf("\nboth the strings are equal");
	else
	printf("\nboth the strings are not equal");
	
	int i, count = 0, pos1, pos2;
	static int times = 0;
    char str[50], key, a[10];
 	printf("\n--------------------------------------------------");
    printf("\nEnter the string\n");
    gets(str);
    printf("\n--------------------------------------------------");
    printf("\nEnter character to be searched\n");
    scanf(" %c", &key);
    printf("\n--------------------------------------------------");
    for (i = 0;i <= strlen(str);i++)
    {
        if (key == str[i])
        {
            count++;
            times++;
            if (count  == 1)
            {
                pos1 = i;
                pos2 = i;
                printf("\nFirst occurence is %d\n", pos1 + 1);
            }
            else 
            {
                pos2 = i;
            }
        }
    }
    printf("Last occurence is %d\n", pos2 + 1);
    printf("No. of Occurence : %d ", times);
	return 0;
}
