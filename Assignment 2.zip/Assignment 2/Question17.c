#include<stdio.h>
#include<string.h>
int main()
{
printf("Choose Option");
printf("\n1. for maximum");
printf("\n2. for minimum");
int a,b,c,d,n;
printf("\nenter 1st number: ");
scanf("%d",&a);
printf("enter 2nd number: ");
scanf("%d",&b);
c=a>b?a:b;
d=a<b?a:b;
printf("\nenter your choice: ");
scanf("%d",&n);
switch(n)
{
case 1:
printf("Maximum number is: %d",c);
break;
case 2:
printf("Minimum number is %d",d);
break;

break;
default:
printf("Choose Correct Option");
}
}
