#include<stdio.h>

int main()
{
int a,b,r1,r2,p=0;
printf("enter 1st number: ");
scanf("%d",&a);
printf("enter 2nd number: ");
scanf("%d",&b);
int t=b;
for(;a>0;)
{
r1=a%10;
t=b;
for(;t>0;)
{
r2=t%10;
p+=r1*r2;
t=t/10;
}
a=a/10;
}
printf("sum of product of digits of the number: %d",p);
}
