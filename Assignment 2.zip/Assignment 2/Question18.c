#include<stdio.h>
#include<string.h>
int bool(int x)
{
if(x>0)
return 1;
else if(x==0)
return 0;
else 
return -1;
}
int main()
{
int n;
printf("\nenter a number: ");
scanf("%d",&n);

int a=bool(n);
switch(a)
{
case 1:
printf("The input number is positive");
break;
case -1:
printf("The input number is negative");
break;
case 0:
printf("The input number is zero");
default:
printf("enter valid input");
}
}
