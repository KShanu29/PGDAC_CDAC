#include<stdio.h>

int main()
{
int a,b,c,d,h;
a=44;
b=22;
c=66;
d=55;
h=(a>b && a>c && a>d)?a:(b>c && b>d)?b:(c>d)?c:d;
printf("The heighest number among four number is: %d",h);

}
