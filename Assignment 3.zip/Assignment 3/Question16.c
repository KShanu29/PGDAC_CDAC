#include<stdio.h>

int main()
{
int n;
printf("enter the no. of rows: ");
scanf("%d",&n);
for(int i=65+n;i>65;i--)
{
for(int j=65;j<i;j++)
{
printf("%c ",j);
}
printf("\n");
}
}
