#include<stdio.h>

int fact(int n)
{
if(n==0)
return 1;
else
return n*fact(n-1);
}

int main()
{
int x;
printf("enter a number to find factorial: ");
scanf("%d",&x);
printf("The factorial of %d is %d",x,fact(x));
}
