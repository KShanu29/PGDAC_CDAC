#include<stdio.h>
#include<math.h>

double main()
{
double x,y;
printf("enter the value of x: ");
scanf("%lf",&x);
printf("enter the value of y: ");
scanf("%lf",&y);
printf("enter the value of y^x is %0.2lf",pow(y,x));
}
