#include<stdio.h>

int main()
{

int n,x,r,sum=0;
printf("enter a number: ");
scanf("%d",&n);
x=n;
while(n>0)
{
r=n%10;
sum+=r;
n=n/10;
}
printf("The sum of all the digits of %d is %d",x,sum);
}
