#include<stdio.h>

int main()
{

int n,x,r,rev=0;
printf("enter a number: ");
scanf("%d",&n);
x=n;
while(n>0)
{
r=n%10;
rev=rev*10+r;
n=n/10;
}
if(x==rev)
printf("The number %d is a pallindrome number",x);
else
printf("The number %d is not a pallindrome number",x);
}
