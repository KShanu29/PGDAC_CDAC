#include<stdio.h>
int main()
{
printf("Nitish kumar Nirala");
}
