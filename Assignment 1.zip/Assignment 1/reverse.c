#include<stdio.h>

int main()
{
int n,rem,rev=0;
printf("enter a four digit number: ");
scanf("%d",&n);
int num=n;
while(n>0)
{
rem=n%10;
rev=rev*10+rem;
n=n/10;
}
printf("The Reverse of %d is %d",num,rev);
}
