#include<stdio.h>

int main()
{
float d1,d2;
printf("Enter distance between two cities respectively(KM): ");
scanf("%f %f",&d1,&d2);

float centi=(d2-d1)*1000*100;

float inch=centi/2.54;

float feet=inch/12;

printf("Distance in centimeter is: %.2f",centi);
printf("\nDistance in centimeter is: %.2f",inch);
printf("\nDistance in centimeter is: %.2f",feet);
}
