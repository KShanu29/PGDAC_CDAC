#include<stdio.h>

int main()
{
int b,h;
printf("Enter Base of the Triangle: ");
scanf("%d",&b);
printf("Enter Height of the Triangle: ");
scanf("%d",&h);

float area=b*h/2;
printf("Area a triangle is: %1f",area);
}
