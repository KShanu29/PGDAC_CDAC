#include<stdio.h>

int main()
{
float a,b;
printf("Enter 1st number: ");
scanf("%f",&a);
printf("Enter 2nd number: ");
scanf("%f",&b);

printf("Subtraction of Two float number is: %f",a-b);
}
