#include<stdio.h>

int main()
{
int n,first_digit,last_digit;
printf("enter a four digit number: ");
scanf("%d",&n);
first_digit=n%10;

while(n>=10)
{
n=n/10;
}
last_digit=n;
printf("Sum of first and last digit is %d",(first_digit+last_digit));
}
