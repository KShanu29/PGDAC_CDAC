#include<stdio.h>

int main()
{
printf("The All primary data types are int, float, char, double");

printf("\nSize of int: %ld",sizeof(int));
printf("\nSize of float: %ld",sizeof(float));
printf("\nSize of char: %ld",sizeof(char));
printf("\nSize of double: %ld",sizeof(double));
}
