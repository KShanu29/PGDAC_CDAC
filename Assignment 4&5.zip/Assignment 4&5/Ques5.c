#include<stdio.h>
#include<math.h>
int armstrong(int n)
{
	int i,rem, result = 0;
	while(n > 0)
	{
		rem = n%10;
		result = result + pow(rem,3);
		n = n/10;
	}
	return 0;
}

void main()
{
   int num, res =0 ;
   printf("Enter number to check armstrong or not : ");
   scanf("%d", &num);
   res = armstrong(num);
	if(res==0)
		printf("\n %d is a armstrong number.",num);
	else
		printf("\n %d is not a armstrong number.",num);
}
