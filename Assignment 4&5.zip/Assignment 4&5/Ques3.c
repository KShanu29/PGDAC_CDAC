#include<stdio.h>

int prime(int n)
{
	int i;
	for(i = 2;i <= n/2;i++)
	{
		if(n%i != 0)
			continue;
		else
			return 1;
	}
	return 0;
}

int main()
{
	int num, res =0;
	printf("Please enter a number to check prime number or not: ");
	scanf("%d", &num);
    res = prime(num);
	if(res==0)
		printf("\n %d IS A PRIME NUMBER",num);
	else
		printf("\n %d IS NOT A PRIME NUMBER",num);
	return 0;	
}
