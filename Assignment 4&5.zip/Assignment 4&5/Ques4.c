#include<stdio.h>

void fibonacciSeries (int range)
{
	int a=0, b=1, temp;

   while (a<=range)
   {
     printf("%d\t", a);
     temp = a+b;
     a = b;
     b = temp;
   }
}

void main()
{
   int range;
   printf("Enter range: ");
   scanf("%d", &range);
   printf("\nThe Fibonacci series is: \n");
   fibonacciSeries(range);
}
