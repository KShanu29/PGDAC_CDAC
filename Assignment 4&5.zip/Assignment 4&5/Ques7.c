#include<stdio.h>
void star_pyramid(int n)
{
	int i,j;
	for( i=0;i<n;i++)
	{
		for( j=0;j<=i;j++)
		{
			printf("* ");
		}
		printf("\n");
	}
}
int main()
{
int num = 5;
star_pyramid(num);
return 0;
}
