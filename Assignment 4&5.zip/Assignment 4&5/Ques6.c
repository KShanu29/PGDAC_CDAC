#include<stdio.h>

int perfect(int n)
{
	int i, rem,result, sum = 0;
	for(i = 1;i <= n ;i++)
	{
		rem = n % i;
		if(rem == 0)
			sum = sum + i;	
	}
	return result= sum/2;
}
void main()
{
   int num, res =0, sum ;
   printf("Enter number to check perfect number or not : ");
   scanf("%d", &num);
   res = perfect(num);
	if(res == num)
		printf("\n %d is a perfect number.",num);
	else
		printf("\n %d is not a perfect number.",num);
}
