#include<stdio.h>

int sum(int n)
{
   int add = 0;
   int result,i;
   for(i=1; i<=n; i++)
   {
     add += i;
   }
   return add;
}

int avg(int n)
{
   int add = 0;
   int result,i;
   for(i=1; i<=n; i++)
   {
     add += i;
   }
   return result = add/n;
}

int main()
{
   int range, Sum;
   float Avg;
   printf("Upto which number you want to find sum: ");
   scanf("%d", &range);
   Sum = sum(range);
   Avg = avg(range);
   printf("1+2+3+�.+%d+%d = %d \n",range-1, range, Sum);
   printf("Average of 1,2,3,...,%d,%d numbers is %.2f ", range -1,range, Avg);
   return 0;
}
