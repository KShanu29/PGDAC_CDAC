#include<stdio.h>
void star_pyramid(int n)
{
	int i,j;
	for( i=0;i<n;i++)
	{
		for( j=0;j<=i;j++)
		{
			printf("* ");
		}
		printf("\n");
	}
}
int main()
{
int num;
printf("Enter no. of rows: ");
scanf("%d", &num);
star_pyramid(num);
return 0;
}
