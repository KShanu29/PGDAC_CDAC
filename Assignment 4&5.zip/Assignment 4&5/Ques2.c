#include<stdio.h>

int fact(int n)
{
   int result;
   if (n == 1)
   	return 1;
   else
   	return n*fact(n -1);
}

int main()
{
   int range;
   printf("Upto which number you want to find factorial: ");
   scanf("%d", &range);
   printf("The factorial of %d is %d", range,fact(range));
   return 0;
}
