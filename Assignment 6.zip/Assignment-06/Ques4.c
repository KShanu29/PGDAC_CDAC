#include<stdio.h>
int Sum(int n,int ar[])
{
	int sum = 0, i;
	for(i=0;i<n;i++)
		sum += ar[i];
	return sum;
}
int main()
{
	int num, i;
	printf("How many numbers you want to find sum: ");
	scanf("%d",&num);
	
	int arr[num];
	printf("Enter %d numbers respectively: \n",num);
	
	for(i=0;i<num;i++)
		scanf("%d",&arr[i]);
	printf("The sum of %d numbers is %d",num,Sum(num,arr));
	return 0;
}
