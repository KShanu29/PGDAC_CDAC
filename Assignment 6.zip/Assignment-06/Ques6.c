#include<stdio.h>

struct employee
{
	int Emp_id,year;
	float salary;
	char Emp_name[20];
};
struct employee emp[10];

int main()
{
	int num,i;
	printf("How many employee's data you want to enter: ");
	scanf("%d",&num);
	
	for(i=1;i<=num;i++)
	{
		printf("Enter Employee's Employee id [%d]: ",i);
		scanf("%d",&emp[i].Emp_id);
		printf("Enter Employee's Name [%d]: ",i);
		scanf("%s",emp[i].Emp_name);
		printf("Enter Employee's salary [%f]: ",i);
		scanf("%f",&emp[i].salary);
		printf("Enter Employee's joining year [%d]: ",i);
		scanf("%d",&emp[i].year);
		printf("_____________________________________________________________\n");
	}
	
	printf("________________Employee Summary__________________________");
	
	for(i=1;i<=num;i++)
	{
		printf("\nEmployee's Employee id [%d]: %d",i,emp[i].Emp_id);
		printf("\nEmployee's Name [%d] : %s",i,emp[i].Emp_name);
		printf("\nEmployee's salary [%d]: %f",i,emp[i].salary);
		printf("\nEmployee's joining year [%d]: %d",i,emp[i].year);
		printf("\n_____________________________________________________________");
	}
	return 0;
}
