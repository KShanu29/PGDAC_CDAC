#include<stdio.h>

int test(int *x)
{
	int y = *x * *x;
	return y;
}

int main()
{
	int a = 10;
	int res = test(&a);
	printf("%d",res);
	return 0;
}
