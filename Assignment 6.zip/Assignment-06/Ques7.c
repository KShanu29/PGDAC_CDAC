#include<stdio.h>

int First_Array(int n1,int ar1[])
{
	int sum1=0,i;
	for(i=0;i<n1;i++)
	sum1+=ar1[i];
	return sum1;
}
int Second_Array(int n2,int ar2[])
{
	int sum2=0,i;
	for(i=0;i<n2;i++)
	sum2+=ar2[i];
	return sum2;
}

int main()
{
	int a,b,i,j;
	printf("Enter the length of 1st array: ");
	scanf("%d",&a);
	int arr1[a];
	printf("Enter %d numbers respectively: ",a);
	for(i=0;i<a;i++)
	scanf("%d",&arr1[i]);
	
	printf("Enter the length of 2nd array: ");
	scanf("%d",&b);
	int arr2[b];
	printf("Enter %d numbers respectively: ",b);
	for(j=0;j<b;j++)
	scanf("%d",&arr2[j]);
	printf("The addition of two array is %d",(First_Array(a,arr1)+Second_Array(b,arr2)));
	return 0;
}
